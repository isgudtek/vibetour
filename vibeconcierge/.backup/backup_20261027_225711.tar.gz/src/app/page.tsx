"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import type { ConciergeResponse, Venue } from "@/types";
const MapView = dynamic(() => import("@/components/MapView"), { ssr: false });

export default function Home() {
  const [clientName, setClientName] = useState("");
  const [destinationCity, setDestinationCity] = useState("Tokyo");
  const [llmProvider, setLlmProvider] = useState<"openrouter" | "groq">("groq");
  const [profileUrl, setProfileUrl] = useState("");
  const [socialText, setSocialText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [tags, setTags] = useState<{ name: string; category: string; qlooTagId?: string; qlooTagName?: string }[]>([]);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [rationale, setRationale] = useState<string>("");
  const [center, setCenter] = useState({ lat: 35.6762, lon: 139.6503 });
  const [selected, setSelected] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string | null>(null);
  const [moreOffset, setMoreOffset] = useState(0);
  const [loadingMore, setLoadingMore] = useState(false);
  const [numDays, setNumDays] = useState(2);
  const [selectedDayRoute, setSelectedDayRoute] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customCategory, setCustomCategory] = useState("Restaurant");
  const [customAddress, setCustomAddress] = useState("");
  const [customDay, setCustomDay] = useState(1);
  const [customSlot, setCustomSlot] = useState(2); // 10:00 AM
  const [customDuration, setCustomDuration] = useState(2);
  const [tripStartDate, setTripStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1); // default tomorrow
    return d.toISOString().slice(0, 10);
  });
  const [autoScheduling, setAutoScheduling] = useState(false);
  const [schedule, setSchedule] = useState<{ uid: string; venueId: string; day: number; startSlot: number; duration: number }[]>([]);
  const [resizingUid, setResizingUid] = useState<string | null>(null);
  const [gated, setGated] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [planReady, setPlanReady] = useState(false);
  const [viewPlan, setViewPlan] = useState(false);
  const [showBriefing, setShowBriefing] = useState(false);

  const hasResults = viewPlan && venues.length > 0;

  useEffect(() => {
    const t = setTimeout(() => {
      try {
        const raw = localStorage.getItem("vibeconcierge_schedule");
        if (raw) {
          const d = JSON.parse(raw);
          if (Array.isArray(d.venues)) setVenues(d.venues);
          if (Array.isArray(d.schedule)) setSchedule(d.schedule.map((x: unknown) => { const r = (x && typeof x === "object" ? x : {}) as Record<string, unknown>; return { uid: String(r.uid ?? ""), venueId: String(r.venueId ?? ""), day: typeof r.day === "number" ? r.day : 1, startSlot: typeof r.startSlot === "number" ? r.startSlot : (typeof r.hour === "number" ? (r.hour - 9) * 2 : 0), duration: typeof r.duration === "number" ? r.duration : 2 }; }));
          if (typeof d.numDays === "number") setNumDays(d.numDays);
          if (typeof d.tripStartDate === "string") setTripStartDate(d.tripStartDate);
          if (d.center) setCenter(d.center);
          setSaveStatus("Restored from browser");
        }
      } catch {}
    }, 0);
    return () => clearTimeout(t);
  }, []);

  async function run() {
    const hasCity = Boolean(destinationCity.trim());
    const hasSource = Boolean(profileUrl.trim() || socialText.trim());

    if (!hasCity && !hasSource) {
      setError("Required fields missing: please enter a destination city and at least one taste source (Public URL or taste description, or both).");
      return;
    }
    if (!hasCity) {
      setError("Required field missing: please enter a destination city (e.g. London, Tokyo).");
      return;
    }
    if (!hasSource) {
      setError("Required field missing: please enter a Public URL, paste taste preferences, or both (if both are filled, the page and text will be combined).");
      return;
    }

    setLoading(true);
    setError(null);
    setGated(false);
    setLogs([]);
    setTags([]);
    setVenues([]);
    setRationale("");
    setSelected(null);
    setTypeFilter(null);
    setSchedule([]);
    setMoreOffset(12);
    setPlanReady(false);
    setViewPlan(false);
    setShowBriefing(false);
    try {
      const res = await fetch("/api/concierge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientName, destinationCity, profileUrl, socialText, provider: llmProvider }),
      });
      const data = (await res.json()) as ConciergeResponse & { error?: string; status?: string; message?: string };
      if (data.status === "gated_error") {
        setGated(true);
        setLogs(data.logs || []);
        setError(data.message || "Profile is login-gated.");
        setLoading(false);
        return;
      }
      if (data.error) throw new Error(data.error);
      for (let i = 0; i < (data.logs || []).length; i++) {
        await new Promise((r) => setTimeout(r, 250));
        setLogs((prev) => [...prev, data.logs[i]]);
      }
      setTags(data.tags || []);
      setVenues(data.venues || []);
      setRationale(data.rationaleReport || "");
      setMoreOffset(12);
      setPlanReady((data.venues || []).length > 0);
      if (data.venues?.length) {
        const lats = data.venues.map((v) => v.lat).filter((x): x is number => typeof x === "number");
        const lons = data.venues.map((v) => v.lon).filter((x): x is number => typeof x === "number");
        if (lats.length) setCenter({ lat: lats.reduce((a, b) => a + b, 0) / lats.length, lon: lons.reduce((a, b) => a + b, 0) / lons.length });
      }
    } catch (e: unknown) {
      setError((e as { message?: string })?.message || "Failed");
    } finally {
      setLoading(false);
    }
  }

  function saveToBrowser() {
    try {
      localStorage.setItem("vibeconcierge_schedule", JSON.stringify({ venues, schedule, numDays, tripStartDate, center, savedAt: Date.now() }));
      setSaveStatus("Saved to browser");
    } catch {
      setSaveStatus("Save failed");
    }
  }

  function clearBrowser() {
    try {
      localStorage.removeItem("vibeconcierge_schedule");
      setSaveStatus("Browser storage cleared");
    } catch {
      setSaveStatus("Clear failed");
    }
  }

  function resetForm() {
    setClientName("");
    setDestinationCity("");
    setProfileUrl("");
    setSocialText("");
    setTags([]);
    setVenues([]);
    setLogs([]);
    setError(null);
    setGated(false);
    setPlanReady(false);
    setSelected(null);
    setRationale("");
    setSchedule([]);
  }

  async function loadMore(category: string) {
    if (loadingMore) return;
    setLoadingMore(true);
    const placeholderId = `loading-${category}-${Date.now()}`;
    setVenues((prev) => [...prev, { id: placeholderId, name: `Scouting ${category}...`, category, affinity: 0, address: `Searching Qloo graph in ${destinationCity}`, tags: [] }]);
    try {
      const r = await fetch("/api/more", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          city: destinationCity,
          tags: tags.map((t) => t.name),
          tagIds: tags.map((t) => t.qlooTagId).filter(Boolean),
          category,
          excluded: venues.map((v) => v.id),
          offset: moreOffset,
        }),
      });
      const d = await r.json();
      const newPlaces = (d.places || []) as Venue[];
      setVenues((prev) => {
        const without = prev.filter((p) => p.id !== placeholderId);
        if (!newPlaces.length) return without;
        const ids = new Set(without.map((p) => p.id));
        const toAdd = newPlaces.filter((p) => !ids.has(p.id));
        if (toAdd.length) {
          // Auto-select the newly discovered venue so the map centers and pops it up
          setTimeout(() => {
            setSelected(toAdd[0].id);
          }, 150);
          return [...without, ...toAdd];
        }
        return without;
      });
      setMoreOffset((o) => o + 12);
      if (newPlaces.length > 0) {
        setSaveStatus(`Found new ${category}: "${newPlaces[0].name}" via Qloo.`);
      } else {
        setSaveStatus(`No additional ${category} venues found for these taste tags.`);
      }
    } catch {
      setVenues((prev) => prev.filter((p) => p.id !== placeholderId));
      setSaveStatus(`Could not fetch additional ${category}.`);
    } finally {
      setLoadingMore(false);
    }
  }

  const ALL_TYPES = ["Bar", "Cafe", "Club", "Hotel", "Museum", "Park", "Restaurant", "Shop", "Theater", "Venue"];
  const types = ALL_TYPES;

  // Active day route coordinates and ordered stops
  const currentTargetDay = selectedDayRoute ?? 1;
  const activeDaySchedule = schedule
    .filter((s) => s.day === currentTargetDay)
    .sort((a, b) => a.startSlot - b.startSlot);

  const dayOrderMap = new Map<string, number>();
  activeDaySchedule.forEach((s, idx) => {
    if (!dayOrderMap.has(s.venueId)) {
      dayOrderMap.set(s.venueId, idx + 1);
    }
  });

  // When a specific day route is selected, show only items on that day ordered by time slot, unless a category filter is active
  let filteredVenues: Venue[];
  if (selectedDayRoute !== null && !typeFilter) {
    // Show only the venues in activeDaySchedule, ordered by schedule time
    const dayVenues: Venue[] = [];
    activeDaySchedule.forEach((s) => {
      const v = venues.find((x) => x.id === s.venueId);
      if (v && !dayVenues.some((item) => item.id === v.id)) {
        dayVenues.push(v);
      }
    });
    filteredVenues = dayVenues;
  } else if (typeFilter) {
    filteredVenues = venues.filter((v) => (v.category || "Venue") === typeFilter);
  } else {
    filteredVenues = venues;
  }

  const mapPlaces = filteredVenues.map((v) => ({
    ...v,
    dayOrder: dayOrderMap.get(v.id),
  }));

  const routeCoordinates = (selectedDayRoute ? activeDaySchedule : [])
    .map((s) => {
      const v = venues.find((x) => x.id === s.venueId);
      return v && typeof v.lat === "number" && typeof v.lon === "number" ? [v.lat, v.lon] as [number, number] : null;
    })
    .filter((pt): pt is [number, number] => pt !== null);

  function handleAddVenueToSchedule(venueId: string) {
    const targetDay = selectedDayRoute ?? 1;
    const v = venues.find((x) => x.id === venueId);
    const daySlots = schedule.filter((s) => s.day === targetDay);
    let nextSlot = 2; // 10:00 AM default
    if (daySlots.length > 0) {
      const maxEndSlot = Math.max(...daySlots.map((s) => s.startSlot + (s.duration || 2)));
      nextSlot = Math.min(20, maxEndSlot + 1);
    }
    setSchedule((prev) => [
      ...prev,
      {
        uid: `${venueId}-${Date.now()}`,
        venueId,
        day: targetDay,
        startSlot: nextSlot,
        duration: 2,
      },
    ]);
    if (v) setSaveStatus(`Added "${v.name}" to Day ${targetDay}.`);
  }

  function handleRemoveVenueFromSchedule(venueId: string) {
    const targetDay = selectedDayRoute ?? 1;
    const v = venues.find((x) => x.id === venueId);
    setSchedule((prev) => prev.filter((s) => !(s.venueId === venueId && s.day === targetDay)));
    if (v) setSaveStatus(`Removed "${v.name}" from Day ${targetDay}.`);
  }

  async function autoBuildSchedule() {
    if (venues.length === 0 || autoScheduling) return;
    setAutoScheduling(true);
    setSaveStatus("Autonomous concierge building schedule...");
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ venues, numDays, provider: llmProvider }),
      });
      const data = await res.json();
      if (Array.isArray(data.schedule) && data.schedule.length > 0) {
        setSchedule(data.schedule);
        setSaveStatus(`Auto-generated itinerary with ${data.schedule.length} curated stops.`);
        setTimeout(() => {
          document.getElementById("schedule-section")?.scrollIntoView({ behavior: "smooth" });
        }, 100);
      } else {
        setSaveStatus("Could not auto-generate schedule.");
      }
    } catch {
      setSaveStatus("Failed to auto-generate schedule.");
    } finally {
      setAutoScheduling(false);
    }
  }

  function addCustomVenue() {
    if (!customName.trim()) return;
    const customId = `custom-${Date.now()}`;
    const newVenue: Venue = {
      id: customId,
      name: customName.trim(),
      category: customCategory,
      address: customAddress.trim() || undefined,
      affinity: 0.95,
      lat: center.lat + (Math.random() - 0.5) * 0.02,
      lon: center.lon + (Math.random() - 0.5) * 0.02,
      rationale: "Custom curated entry added by host.",
    };
    setVenues((prev) => [newVenue, ...prev]);
    setSchedule((prev) => [
      ...prev,
      {
        uid: `${customId}-slot`,
        venueId: customId,
        day: customDay,
        startSlot: customSlot,
        duration: customDuration,
      },
    ]);
    setCustomName("");
    setCustomAddress("");
    setShowAddModal(false);
    setSaveStatus(`Added "${newVenue.name}" to Day ${customDay}.`);
  }

  function getGCalSingleUrl(item: { venueId: string; day: number; startSlot: number; duration: number }) {
    const v = venues.find((x) => x.id === item.venueId);
    const start = formatCalDate(item.day, item.startSlot);
    const end = formatCalDate(item.day, item.startSlot + (item.duration || 2));
    const title = v?.name || "Itinerary Stop";
    const details = `${v?.category || "Venue"}${v?.address ? " - " + v.address : ""}${v?.rationale ? "\n\n" + v.rationale : ""}`;
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${start}/${end}&details=${encodeURIComponent(details)}&location=${encodeURIComponent(v?.address || "")}`;
  }

  function slotToHM(slot: number) {
    const total = 9 * 60 + slot * 30;
    return { h: Math.floor(total / 60), m: total % 60 };
  }

  function getDateForDay(day: number): { y: number; m: number; d: number } {
    const parts = (tripStartDate || "2026-10-28").split("-").map(Number);
    const y = parts[0] || 2026;
    const m = (parts[1] || 10) - 1;
    const d = parts[2] || 28;
    const target = new Date(Date.UTC(y, m, d + (day - 1)));
    return { y: target.getUTCFullYear(), m: target.getUTCMonth() + 1, d: target.getUTCDate() };
  }

  function formatCalDate(day: number, slot: number): string {
    const dt = getDateForDay(day);
    const hm = slotToHM(slot);
    const yStr = String(dt.y).padStart(4, "0");
    const mStr = String(dt.m).padStart(2, "0");
    const dStr = String(dt.d).padStart(2, "0");
    const hStr = String(hm.h).padStart(2, "0");
    const minStr = String(hm.m).padStart(2, "0");
    return `${yStr}${mStr}${dStr}T${hStr}${minStr}00`;
  }

  function exportGoogleCalendar() {
    if (schedule.length === 0) return;
    const sorted = schedule.slice().sort((a, b) => a.day - b.day || a.startSlot - b.startSlot);
    
    // Google Calendar URL template only supports one event at a time.
    // If the schedule has multiple items, opening multiple tabs can be blocked by popup blockers.
    // We open up to the first 4 events in separate tabs or download the full multi-event ICS for 1-click import.
    sorted.forEach((item, index) => {
      const url = getGCalSingleUrl(item);
      setTimeout(() => {
        window.open(url, "_blank");
      }, index * 250);
    });
    setSaveStatus(`Opening ${sorted.length} Google Calendar event tabs. Tip: You can also use "Download for Google Calendar (.ICS)" for 1-click import!`);
  }

  function downloadCSVCalendar() {
    // Google Calendar native CSV format
    // Header format: Subject,Start Date,Start Time,End Date,End Time,All Day Event,Description,Location
    const rows = [
      ["Subject", "Start Date", "Start Time", "End Date", "End Time", "All Day Event", "Description", "Location"],
      ...schedule.slice().sort((a, b) => a.day - b.day || a.startSlot - b.startSlot).map((s) => {
        const v = venues.find((x) => x.id === s.venueId);
        const dt = getDateForDay(s.day);
        const st = slotToHM(s.startSlot);
        const et = slotToHM(s.startSlot + (s.duration || 2));
        const dateStr = `${String(dt.m).padStart(2, "0")}/${String(dt.d).padStart(2, "0")}/${dt.y}`;
        const startTimeStr = `${String(st.h).padStart(2, "0")}:${String(st.m).padStart(2, "0")}`;
        const endTimeStr = `${String(et.h).padStart(2, "0")}:${String(et.m).padStart(2, "0")}`;
        const subject = `VibeConcierge: ${v?.name || s.venueId} (${v?.category || "Stop"})`;
        const desc = `${v?.category || "Venue"}${v?.address ? " - " + v.address : ""}${v?.rationale ? "\n" + v.rationale : ""}`;
        const loc = v?.address || "";
        return [subject, dateStr, startTimeStr, dateStr, endTimeStr, "False", desc, loc];
      }),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "google_calendar_itinerary.csv";
    a.click();
    URL.revokeObjectURL(url);
    setSaveStatus("Downloaded Google Calendar CSV (ready for Google Calendar Import in Settings).");
  }

  function downloadICS() {
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//VibeConcierge//EN"];
    schedule.forEach((item, i) => {
      const venue = venues.find((v) => v.id === item.venueId);
      const dur = item.duration || 2;
      const start = formatCalDate(item.day, item.startSlot);
      const end = formatCalDate(item.day, item.startSlot + dur);
      lines.push("BEGIN:VEVENT");
      lines.push(`UID:vibe-${i}-${Date.now()}@vibeconcierge`);
      lines.push(`SUMMARY:Day ${item.day} - ${venue?.name || item.venueId}`);
      lines.push(`DESCRIPTION:${venue?.category || ""} - ${venue?.address || ""}`);
      if (venue?.address) lines.push(`LOCATION:${venue.address}`);
      if (typeof venue?.lat === "number" && typeof venue?.lon === "number") lines.push(`GEO:${venue.lat};${venue.lon}`);
      lines.push(`DTSTART:${start}`);
      lines.push(`DTEND:${end}`);
      lines.push("END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    const blob = new Blob([lines.join("\r\n")], { type: "text/calendar" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "vibeconcierge_itinerary.ics";
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!hasResults) {
    return (
      <div className="page page-hero">
        <div className="hero">
          <div className="hero-bg" />
          <div className="hero-grid">
            <div className="hero-claim">
              <h1>Semi-autonomous taste-driven tour organizer</h1>
              <p>VibeConcierge transforms an incoming guest&apos;s public cultural footprint into a high-taste host itinerary in your city — powered by Qloo&apos;s taste graph, not generic LLM guesses.</p>
              <div style={{ marginTop: 16, display: "flex", gap: 10, flexWrap: "wrap" }}>
                <span className="chip">Qloo taste graph</span>
                <span className="chip">Groq LLM</span>
                <span className="chip">Interactive map</span>
              </div>

              <div className="card usecase-parent-card">
                <div className="card-head" style={{ marginBottom: 10 }}>
                  <div>
                    <h2 style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--amber)", fontWeight: 700 }}>
                      USECASES
                    </h2>
                    <p style={{ fontSize: 12, color: "var(--text-3)", margin: 0 }}>
                      Dual-market cultural discovery engine
                    </p>
                  </div>
                </div>

                <div className="usecase-row">
                  <div className="usecase-subcard">
                    <span className="usecase-tag">Personal</span>
                    <p className="usecase-desc">You and friends are visiting a city. Enter your preferences to uncover culturally matched spots.</p>
                  </div>

                  <div className="usecase-subcard">
                    <span className="usecase-tag">Tour operators / B2B</span>
                    <p className="usecase-desc">A client is visiting your company for a few days. Enter their preferences or fetch their socials to find out.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="card" style={{ background: "rgba(25,24,22,0.72)", backdropFilter: "blur(12px)" }}>
              <div className="card-head" style={{ alignItems: "center", marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--tile)", padding: "3px 6px", borderRadius: 8, border: "1px solid var(--line-strong)" }}>
                  <span style={{ fontSize: 10, color: "var(--text-3)", textTransform: "uppercase", letterSpacing: "0.04em" }}>Model:</span>
                  <button
                    type="button"
                    onClick={() => setLlmProvider("openrouter")}
                    style={{
                      border: "none",
                      background: llmProvider === "openrouter" ? "var(--amber)" : "transparent",
                      color: llmProvider === "openrouter" ? "#1a1612" : "var(--text-2)",
                      borderRadius: 4,
                      padding: "2px 6px",
                      fontSize: 10,
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    OpenRouter (Auto Free)
                  </button>
                  <button
                    type="button"
                    onClick={() => setLlmProvider("groq")}
                    style={{
                      border: "none",
                      background: llmProvider === "groq" ? "var(--amber)" : "transparent",
                      color: llmProvider === "groq" ? "#1a1612" : "var(--text-2)",
                      borderRadius: 4,
                      padding: "2px 6px",
                      fontSize: 10,
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    Groq
                  </button>
                </div>
                <button
                  type="button"
                  onClick={resetForm}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 5,
                    background: "var(--tile)",
                    border: "1px solid var(--line-strong)",
                    padding: "4px 10px",
                    borderRadius: 8,
                    color: "var(--text-2)",
                    fontSize: 10,
                    fontWeight: 600,
                    cursor: "pointer",
                    letterSpacing: "0.03em",
                  }}
                  title="Reset all form fields"
                >
                  ↻ Reset form
                </button>
              </div>
              <div className="stack">
                <input className="field" value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="Guest / group name (e.g. Kenji Tanaka, Sarah & Friends)" />
                
                <div>
                  <input
                    className={`field ${!destinationCity.trim() && error ? "field-error" : ""}`}
                    value={destinationCity}
                    onChange={(e) => {
                      setDestinationCity(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Destination city * (required, e.g. London, Tokyo)"
                  />
                  {!destinationCity.trim() && error && (
                    <span style={{ color: "var(--coral)", fontSize: 11, display: "block", marginTop: 3 }}>
                      * Destination city is required
                    </span>
                  )}
                </div>

                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: "var(--text-3)", textTransform: "uppercase", letterSpacing: "0.04em" }}>
                      Taste Source (Public URL, Text, or both) *
                    </span>
                    <span style={{ fontSize: 10, color: "var(--amber)" }}>Min 1 required (combines both if provided)</span>
                  </div>
                  <input
                    className={`field ${!profileUrl.trim() && !socialText.trim() && error ? "field-error" : ""}`}
                    value={profileUrl}
                    onChange={(e) => {
                      setProfileUrl(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Public URL (Wikipedia, blog, article...)"
                  />
                  <div className="row" style={{ marginTop: 4, marginBottom: 8 }}>
                    <button className="btn" type="button" onClick={() => { setProfileUrl("https://en.wikipedia.org/wiki/Karl_Marx"); if (error) setError(null); }} style={{ height: 24, fontSize: 11 }}>Karl Marx (Wikipedia)</button>
                    <button className="btn" type="button" onClick={() => { setProfileUrl("https://en.wikipedia.org/wiki/Elon_Musk"); if (error) setError(null); }} style={{ height: 24, fontSize: 11 }}>Elon Musk (Wikipedia)</button>
                  </div>
                  <textarea
                    className={`field ${!profileUrl.trim() && !socialText.trim() && error ? "field-error" : ""}`}
                    value={socialText}
                    onChange={(e) => {
                      setSocialText(e.target.value);
                      if (error) setError(null);
                    }}
                    rows={3}
                    style={{ resize: "vertical" }}
                    placeholder="Paste taste preferences, sub-culture tastes, or bio text (if both URL and text are filled, they will be combined)..."
                  />
                  {!profileUrl.trim() && !socialText.trim() && error && (
                    <span style={{ color: "var(--coral)", fontSize: 11, display: "block", marginTop: 3 }}>
                      * Please provide at least one: Public URL or taste text (or both)
                    </span>
                  )}
                </div>

                {gated && <p style={{ color: "var(--coral)", fontSize: 12, margin: 0 }}>OSINT ALERT: profile is gated. Paste public text above and re-run.</p>}
                <p style={{ color: "var(--text-3)", fontSize: 11, margin: 0 }}>Facebook/LinkedIn are login-gated; Jina cannot read them. Paste public About/Interests text above for extraction.</p>
                <div className="row" style={{ marginTop: 6 }}>
                  <button className="btn" type="button" onClick={() => {
                    setSocialText(`Kenji Tanaka is a 34-year-old Senior Creative Director at a boutique digital agency based in Tokyo’s high-design Daikanyama district. He possesses a deeply curated, minimalist aesthetic that heavily influences both his professional work and his personal lifestyle choices. Rather than following mainstream global trends, Kenji aligns himself with niche sub-cultures, displaying a strong preference for mid-century brutalist architecture, independent Japanese menswear labels, and rare architectural publications.
When it comes to his off-duty hours, Kenji’s cultural footprint spans high-fidelity audio and artisanal craftsmanship. He is an avid collector of vintage jazz and electronic vinyl records, frequently spending his evenings scouting hidden, underground listening bars across Shibuya. His daytime routine is anchored by third-wave specialty coffee roasters that focus on single-origin beans and clean, geometric interior spaces, reflecting his broader appreciation for functionalism and understated luxury.
As a traveler visiting an international city like London, Kenji completely avoids typical commercial tourist spots, actively seeking out places that mirror Tokyo’s sub-cultural DNA. He prioritizes heritage menswear boutiques that focus on sustainable craftsmanship, independent design bookshops, and low-lit cocktail lounges that play ambient or experimental cuts over a high-end sound system. For a host executive looking to build genuine rapport, presenting an itinerary that speaks directly to these micro-tastes is the ultimate key to unlocking a lasting professional relationship.`);
                    if (error) setError(null);
                  }} style={{ height: 26, fontSize: 11 }}>
                    Kenji
                  </button>
                  <button className="btn" type="button" onClick={() => {
                    setSocialText('Fiona Lindström is a 42-year-old Chief Operating Officer at a leading Stockholm-based green technology firm, embodying the effortless elegance of modern Scandinavian leadership. She lives by the Swedish philosophy of lagom—finding the perfect balance of functional utility and understated premium design. Her lifestyle centers on clean geometric forms, organic materials, and sustainable luxury, preferring independent Nordic interior design concepts and eco-conscious heritage fashion brands over loud corporate logos.\nOutside the boardroom, Fiona is an avid wellness and contemporary art enthusiast. Her mornings typically begin with visits to specialty micro-roasters that prioritize fair-trade, light-roast single-origin coffees, and her weekends are often spent exploring minimalist modern art galleries or attending acoustic neo-classical music performances. When dining out, she seeks out hyper-local, farm-to-table culinary experiences that focus on innovative, seasonal ingredients and Nordic gastronomy principles.\nWhen traveling to a major international hub like London for executive meetings, Fiona has zero interest in generic luxury hotels or crowded tourist staples. She leans toward high-design boutique accommodations, quiet independent art bookstores, and hidden culinary spaces that fuse architectural design with strict sustainability standards. To truly impress her and secure a strategic partnership, a host executive must look past basic corporate hospitality and curate an itinerary that aligns with her values of high-concept design, environmental mindfulness, and quiet sophistication. ');
                    if (error) setError(null);
                  }} style={{ height: 26, fontSize: 11 }}>
                    Fiona
                  </button>
                  <button className="btn" type="button" onClick={() => {
                    setSocialText('Carlos Vega is a 38-year-old Managing Partner at a leading early-stage venture capital firm based in Madrid’s vibrant Chamberí district. He represents the new wave of southern European tech investors, blending sharp financial acumen with an active, high-energy Mediterranean lifestyle. Carlos favors a "smart-casual" executive aesthetic, completely bypassing traditional corporate suits in favor of premium unstructured blazers, independent Spanish artisanal leather footwear, and minimalist luxury timepieces.\nAway from the pitch deck, Carlos is a deeply passionate culinary explorer and an avid indie-rock enthusiast. He spends his weekends seeking out hidden natural wine bars, underground live music venues, and conceptual tapas galleries that reinvent traditional Iberian flavors through avant-garde gastronomy. His morning routine is anchored by third-wave espresso lounges that feature striking contemporary art, reflecting his personal passion for collecting emerging Spanish abstract paintings and graphic prints.\nWhen flying into an international financial hub like London to scout cross-border deals or meet limited partners, Carlos skips generic institutional hotels and mainstream steak houses. He actively hunts for high-design boutique stays, hidden vinyl-listening cocktail bars, and energetic, chef-driven culinary laboratories that bridge cultural heritage with modern execution. For an entrepreneur or host executive aiming to build a high-trust relationship with him, orchestrating an evening that taps into this exact mix of indie culture, modern art, and bleeding-edge gastronomy is the ultimate way to close the deal. ');
                    if (error) setError(null);
                  }} style={{ height: 26, fontSize: 11 }}>
                    Carlos
                  </button>
                  <button className="btn" type="button" disabled={generating} onClick={async () => {
                    setGenerating(true);
                    try {
                      const r = await fetch("/api/generate", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ provider: llmProvider }),
                      });
                      const d = await r.json();
                      if (d.text) {
                        setSocialText(d.text);
                        if (error) setError(null);
                      }
                      else if (d.error) alert(d.error);
                    } catch { alert("Generate failed"); }
                    finally { setGenerating(false); }
                  }} style={{ height: 26, fontSize: 11 }}>
                    {generating ? "Generating..." : "Generate with Groq"}
                  </button>
                </div>
                <button className="btn btn-primary" onClick={() => { if (planReady && venues.length > 0) setViewPlan(true); else run(); }} disabled={loading} style={{ height: 38, width: "100%", animation: planReady ? "blink 1.2s infinite" : "none" }}>
                  {loading ? "Deploying scan..." : planReady ? "View the plan" : "Deploy autonomous vibe scan"}
                </button>
                {planReady && rationale && (
                  <button className="btn" onClick={() => setShowBriefing(true)} style={{ height: 34, width: "100%", marginTop: 6 }}>
                    View strategic briefing
                  </button>
                )}
                {error && <p style={{ color: "var(--coral)", fontSize: 13 }}>{error}</p>}
                {tags.length > 0 && (
                  <div className="row">
                    {tags.map((t, i) => (
                      <span key={i} className="chip">{t.name} <span style={{ color: "var(--text-3)" }}>({t.category})</span>{t.qlooTagName && t.qlooTagName.toLowerCase() !== t.name.toLowerCase() ? <span style={{ color: "var(--light)" }}> → {t.qlooTagName}</span> : null}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

      {/* Compact execution pane */}
      <div style={{ position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 1000, background: "rgba(10,9,8,0.92)", backdropFilter: "blur(8px)", borderTop: "1px solid var(--line-strong)", padding: "6px 12px", fontFamily: "monospace", fontSize: 11, color: "#9cdcfe", height: 44, overflow: "auto" }}>
        {logs.length === 0 ? "Waiting for execution..." : logs[logs.length - 1]}
      </div>
          {showBriefing && (
            <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
              <div className="card" style={{ maxWidth: 720, width: "100%", maxHeight: "80vh", overflow: "auto" }}>
                <div className="card-head">
                  <div>
                    <h2>Strategic briefing</h2>
                    <p>Corporate strategy report</p>
                  </div>
                  <button className="btn" onClick={() => setShowBriefing(false)}>Close</button>
                </div>
                <div className="pick">
                  <div className="reason" style={{ whiteSpace: "pre-wrap" }}>{rationale}</div>
                </div>
                <div className="pick">
                  <div className="cat">Reasoning report</div>
                  <div style={{ background: "#0a0908", border: "1px solid var(--line)", borderRadius: 10, padding: 10, fontFamily: "monospace", fontSize: 11, color: "#9cdcfe", maxHeight: 220, overflow: "auto" }}>
                    {logs.map((l, i) => <div key={i}>{l}</div>)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <svg className="backdrop" viewBox="0 0 1440 1080" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <g fill="none" stroke="rgba(250,240,225,0.10)" strokeWidth="1" strokeDasharray="2 4">
          <ellipse cx="720" cy="560" rx="560" ry="760" />
          <ellipse cx="720" cy="560" rx="360" ry="760" />
          <ellipse cx="720" cy="560" rx="150" ry="760" />
          <ellipse cx="720" cy="560" rx="760" ry="760" />
          <ellipse cx="720" cy="560" rx="980" ry="820" />
        </g>
        <circle cx="1252" cy="262" r="30" fill="rgba(250,240,225,0.03)" stroke="rgba(250,240,225,0.10)" strokeDasharray="2 4" />
      </svg>

      <header className="top">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="5.5" stroke="#eda645" strokeWidth="1.6" /><path d="M8 2.5v11" stroke="#eda645" strokeWidth="1.6" strokeLinecap="round" /></svg>
          </span>
          VibeConcierge <small>Corporate hospitality agent</small>
        </div>
        <div className="desktop-menu">
          <button className="btn" onClick={() => document.getElementById("map-section")?.scrollIntoView({ behavior: "smooth" })}>Map</button>
          <button className="btn" onClick={() => document.getElementById("schedule-section")?.scrollIntoView({ behavior: "smooth" })}>Planner</button>
          <button className="btn" onClick={() => document.getElementById("briefing-section")?.scrollIntoView({ behavior: "smooth" })}>Report</button>
          <button className="btn" onClick={() => setViewPlan(false)}>Back home</button>
        </div>
      </header>
      <nav className="mobile-nav">
        <button className="btn" onClick={() => document.getElementById("map-section")?.scrollIntoView({ behavior: "smooth" })}>Map</button>
        <button className="btn" onClick={() => document.getElementById("schedule-section")?.scrollIntoView({ behavior: "smooth" })}>Planner</button>
        <button className="btn" onClick={() => document.getElementById("briefing-section")?.scrollIntoView({ behavior: "smooth" })}>Report</button>
        <button className="btn" onClick={() => setViewPlan(false)}>Home</button>
      </nav>

      <div style={{ maxWidth: 1200, margin: "0 auto", width: "100%" }} className="stack">
        {/* Map with overlay list */}
        <section id="map-section" className="results-wrap">
          <MapView
            center={center}
            places={mapPlaces}
            routeCoordinates={routeCoordinates}
            loading={loading}
            selectedId={selected}
            onSelect={(id) => {
              setSelected(id);
              const v = venues.find((x) => x.id === id);
              if (v?.category) setTypeFilter(v.category);
            }}
            activeDay={selectedDayRoute}
            onAddToSchedule={handleAddVenueToSchedule}
            onRemoveFromSchedule={handleRemoveVenueFromSchedule}
          />
          <div className="results-overlay card" style={{ padding: 14 }}>
            <div className="card-head" style={{ marginBottom: 8 }}>
              <div>
                <h2 style={{ fontSize: 14 }}>
                  {selectedDayRoute !== null && !typeFilter ? `Day ${selectedDayRoute} Itinerary` : "Connected list"}
                </h2>
                <p style={{ fontSize: 12 }}>
                  {selectedDayRoute !== null && !typeFilter ? `${filteredVenues.length} stops scheduled in sequence` : "Click to focus map"}
                </p>
              </div>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                {tags.length > 0 && (
                  <button
                    className="btn"
                    style={{ fontSize: 11, padding: "2px 8px", height: 24, borderColor: "var(--amber)", color: "var(--amber)" }}
                    onClick={() => setShowBriefing(true)}
                    title="See Qloo entity and tag mappings"
                  >
                    🔍 Qloo Graph ({tags.filter(t => t.qlooTagId).length} tags)
                  </button>
                )}
                <div className="big num" style={{ fontSize: 18 }}>{filteredVenues.length}<small>shown</small></div>
              </div>
            </div>

            {/* Quick Auto-fill Schedule button right on the map overlay */}
            <div style={{ marginBottom: 10, display: "flex", gap: 6, flexWrap: "wrap" }}>
              <button
                className="btn btn-primary"
                onClick={autoBuildSchedule}
                disabled={autoScheduling || venues.length === 0}
                style={{
                  flex: 1,
                  height: 30,
                  fontSize: 12,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  background: "var(--amber)",
                  color: "#1a1612",
                  fontWeight: 600,
                  border: "none",
                }}
                title="Automatically build and populate schedule from these venues"
              >
                {autoScheduling ? "✦ Auto-filling..." : "✦ Auto-fill Schedule"}
              </button>
              {rationale && (
                <button
                  className="btn"
                  onClick={() => setShowBriefing(true)}
                  style={{
                    height: 30,
                    fontSize: 12,
                    padding: "0 10px",
                    borderColor: "var(--amber)",
                    color: "var(--amber)",
                  }}
                  title="View AI Corporate Strategy Report & Taste Rationale"
                >
                  📜 Strategic report
                </button>
              )}
            </div>

            {/* Day Route Filter Chips on Map */}
            {schedule.length > 0 && (
              <div className="row" style={{ marginBottom: 10, paddingBottom: 6, borderBottom: "1px solid var(--line)" }}>
                <span style={{ fontSize: 11, color: "var(--text-3)", textTransform: "uppercase", letterSpacing: "0.05em" }}>Route:</span>
                <span
                  className="chip"
                  onClick={() => setSelectedDayRoute(null)}
                  style={{ cursor: "pointer", borderColor: selectedDayRoute === null ? "var(--amber)" : undefined, fontSize: 11, padding: "2px 8px" }}
                >
                  All Places
                </span>
                {Array.from({ length: numDays }, (_, i) => i + 1).map((d) => {
                  const count = schedule.filter((s) => s.day === d).length;
                  return (
                    <span
                      key={d}
                      className="chip"
                      onClick={() => {
                        const nextDay = selectedDayRoute === d ? null : d;
                        setSelectedDayRoute(nextDay);
                        if (nextDay !== null) {
                          // Toggle off category filter so the map displays only items on that day
                          setTypeFilter(null);
                        }
                      }}
                      style={{
                        cursor: "pointer",
                        borderColor: selectedDayRoute === d ? "var(--amber)" : undefined,
                        background: selectedDayRoute === d ? "rgba(237,166,69,0.15)" : undefined,
                        color: selectedDayRoute === d ? "var(--amber)" : undefined,
                        fontSize: 11,
                        padding: "2px 8px",
                      }}
                    >
                      Day {d} ({count})
                    </span>
                  );
                })}
              </div>
            )}
            <div className="row" style={{ marginBottom: 8 }}>
              <span className="chip" onClick={() => setTypeFilter(null)} style={{ cursor: "pointer", borderColor: typeFilter === null ? "var(--amber)" : undefined }}>All</span>
              {types.map((t) => (
                <span key={t} className="chip" style={{ display: "inline-flex", alignItems: "center", gap: 4, borderColor: typeFilter === t ? "var(--amber)" : undefined }}>
                  <span onClick={() => setTypeFilter(typeFilter === t ? null : t)} style={{ cursor: "pointer" }}>{t} ({venues.filter((v) => (v.category || "Venue") === t).length})</span>
                  <button onClick={() => loadMore(t)} disabled={loadingMore} style={{ background: "transparent", border: "none", color: "var(--amber)", cursor: "pointer", fontSize: 12, padding: 0, lineHeight: 1 }} title={`Load another ${t}`}>+</button>
                </span>
              ))}
            </div>
            <div className="stack" style={{ overflow: "auto", maxHeight: "calc(72vh - 120px)" }}>
              {filteredVenues.map((v) => {
                const stopNumber = dayOrderMap.get(v.id);
                return (
                  <div
                    key={v.id}
                    className="pick"
                    onClick={() => {
                      setSelected(v.id);
                      // If user selects an item while filtered to a day, reactivate its category
                      if (v.category) {
                        setTypeFilter(v.category);
                      }
                    }}
                    style={{ cursor: "pointer", borderColor: selected === v.id ? "var(--amber)" : undefined }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div className="name" style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span>{v.name}</span>
                        {stopNumber && (
                          <span style={{ background: "var(--amber)", color: "#1a1612", fontSize: 10, fontWeight: 700, padding: "2px 6px", borderRadius: 10, whiteSpace: "nowrap" }}>
                            Stop #{stopNumber}
                          </span>
                        )}
                      </div>
                      <div className="score num" style={{ fontSize: 14 }}>{Math.round(v.affinity * 100)}%</div>
                    </div>
                    <div className="reason">
                      {v.category}{v.address ? ` · ${v.address}` : ""}
                      {stopNumber ? ` · Day ${selectedDayRoute ?? 1}` : ""}
                    </div>
                    {v.rationale && <div className="reason" style={{ marginTop: 4 }}>{v.rationale}</div>}
                    
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
                      {stopNumber ? (
                        <button
                          className="btn"
                          style={{ height: 26, padding: "0 10px", fontSize: 12, borderColor: "var(--coral)", color: "var(--coral)" }}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveVenueFromSchedule(v.id);
                          }}
                        >
                          ✕ Remove from Day {selectedDayRoute ?? 1}
                        </button>
                      ) : (
                        <button
                          className="btn"
                          style={{ height: 26, padding: "0 10px", fontSize: 12 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAddVenueToSchedule(v.id);
                          }}
                        >
                          + Send to schedule {selectedDayRoute ? `(Day ${selectedDayRoute})` : "(Day 1)"}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Bottom yellow query button per selected/active category */}
              <button
                className="btn btn-primary"
                onClick={() => loadMore(typeFilter || "Venue")}
                disabled={loadingMore}
                style={{
                  marginTop: 10,
                  height: 34,
                  fontSize: 12,
                  fontWeight: 600,
                  background: "var(--amber)",
                  color: "#1a1612",
                  border: "none",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                }}
              >
                {loadingMore
                  ? `Querying Qloo for ${typeFilter || "more places"}...`
                  : `Query Qloo for ${typeFilter || "Venue"}`}
              </button>
            </div>
          </div>
        </section>

        {/* Composable schedule */}
        <section id="schedule-section" className="card" style={{ width: "100%" }}>
          <div className="card-head">
            <div>
              <h2>Composable schedule</h2>
              <p>Auto-assign or drag venues into daily time slots</p>
            </div>
            <div className="row" style={{ gap: 12 }}>
              <button
                className="btn btn-primary"
                onClick={autoBuildSchedule}
                disabled={autoScheduling || venues.length === 0}
                style={{ height: 28, fontSize: 12, display: "flex", alignItems: "center", gap: 5 }}
                title="Automatically arrange places across the days based on category & flow"
              >
                {autoScheduling ? "✦ Auto-filling..." : "✦ Auto-fill Schedule"}
              </button>
              <button
                className="btn"
                onClick={() => setShowAddModal(true)}
                style={{ height: 28, fontSize: 12 }}
                title="Add a custom stop manually"
              >
                + Add Stop
              </button>
              <div className="row" style={{ gap: 6 }}>
                <span style={{ color: "var(--text-2)", fontSize: 13 }}>Start date</span>
                <input
                  type="date"
                  value={tripStartDate}
                  onChange={(e) => setTripStartDate(e.target.value)}
                  className="field"
                  style={{ width: 130, padding: "3px 6px", fontSize: 12 }}
                />
              </div>
              <div className="row" style={{ gap: 6 }}>
                <span style={{ color: "var(--text-2)", fontSize: 13 }}>Days</span>
                <input type="number" min={1} max={7} value={numDays} onChange={(e) => setNumDays(Math.max(1, Math.min(7, Number(e.target.value) || 1)))} className="field" style={{ width: 56, padding: "3px 6px", fontSize: 12 }} />
              </div>
            </div>
          </div>
          <div style={{ overflow: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12, tableLayout: "fixed" }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left", padding: 6, color: "var(--text-3)", fontWeight: 500, width: 44 }}>Hour</th>
                  {Array.from({ length: numDays }, (_, i) => {
                    const d = i + 1;
                    const isSelectedRoute = selectedDayRoute === d;
                    return (
                      <th
                        key={i}
                        onClick={() => {
                          const nextDay = isSelectedRoute ? null : d;
                          setSelectedDayRoute(nextDay);
                          if (nextDay !== null) setTypeFilter(null);
                        }}
                        style={{
                          textAlign: "left",
                          padding: "6px 8px",
                          color: isSelectedRoute ? "var(--amber)" : "var(--text-2)",
                          fontWeight: 600,
                          width: `calc((100% - 44px) / ${numDays})`,
                          cursor: "pointer",
                          background: isSelectedRoute ? "rgba(237,166,69,0.08)" : undefined,
                          borderTopLeftRadius: 6,
                          borderTopRightRadius: 6,
                        }}
                        title={`Click to show route for Day ${d} on map`}
                      >
                        Day {d} {isSelectedRoute ? "📍 (On Map)" : ""}
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: 23 }, (_, slot) => {
                  const t = { h: Math.floor((9 * 60 + slot * 30) / 60), m: (9 * 60 + slot * 30) % 60 };
                  const label = `${String(t.h).padStart(2, "0")}:${String(t.m).padStart(2, "0")}`;
                  return (
                    <tr key={slot}>
                      <td style={{ padding: 6, color: "var(--text-3)", borderTop: "1px solid var(--line)", width: 60, verticalAlign: "top" }}>{label}</td>
                      {Array.from({ length: numDays }, (_, di) => {
                        const day = di + 1;
                        const starting = schedule.find((s) => s.day === day && s.startSlot === slot);
                        const covering = schedule.find((s) => s.day === day && s.startSlot < slot && s.startSlot + (s.duration || 1) > slot);
                        if (covering) return null;
                        if (!starting) {
                          return (
                            <td
                              key={day}
                              onDragOver={(e) => e.preventDefault()}
                              onDrop={(e) => {
                                e.preventDefault();
                                const uid = e.dataTransfer.getData("text/plain");
                                setSchedule((prev) => prev.map((s) => (s.uid === uid ? { ...s, day, startSlot: slot } : s)));
                              }}
                              style={{ padding: 4, borderTop: "1px solid var(--line)", height: 32, verticalAlign: "top", width: `calc((100% - 44px) / ${numDays})`, wordBreak: "break-word", whiteSpace: "normal" }}
                            />
                          );
                        }
                        const v = venues.find((x) => x.id === starting.venueId);
                        const span = Math.max(1, starting.duration || 1);
                        return (
                          <td
                            key={day}
                            rowSpan={span}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={(e) => {
                              e.preventDefault();
                              const uid = e.dataTransfer.getData("text/plain");
                              setSchedule((prev) => prev.map((s) => (s.uid === uid ? { ...s, day, startSlot: slot } : s)));
                            }}
                            style={{ padding: 4, borderTop: "1px solid var(--line)", verticalAlign: "top", width: `calc((100% - 44px) / ${numDays})`, wordBreak: "break-word", whiteSpace: "normal", position: "relative", overflow: "hidden" }}
                          >
                            <div
                              draggable={resizingUid !== starting.uid}
                              onDragStart={(e) => {
                                if (resizingUid === starting.uid) { e.preventDefault(); return; }
                                e.dataTransfer.setData("text/plain", starting.uid);
                              }}
                              onClick={() => {
                                setSelected(starting.venueId);
                                document.getElementById("map-section")?.scrollIntoView({ behavior: "smooth" });
                              }}
                              className="pick"
                              style={{
                                cursor: "grab",
                                padding: 6,
                                paddingBottom: 16,
                                position: "absolute",
                                top: 4,
                                left: 4,
                                right: 4,
                                bottom: 4,
                                overflow: "hidden",
                                borderColor: selected === starting.venueId ? "var(--amber)" : undefined,
                                background: selected === starting.venueId ? "rgba(237,166,69,0.12)" : undefined,
                              }}
                              title="Click to view on Map"
                            >
                              <button onClick={(e) => { e.stopPropagation(); setSchedule((prev) => prev.filter((x) => x.uid !== starting.uid)); }} style={{ position: "absolute", top: 2, right: 4, background: "transparent", border: "none", color: "var(--text-3)", cursor: "pointer", fontSize: 13, lineHeight: 1 }}>×</button>
                              <div className="name" style={{ fontSize: 11, fontWeight: 600, paddingRight: 14 }}>{v?.name || starting.venueId}</div>
                              <div className="meta" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.04em", display: "flex", justifyContent: "space-between" }}>
                                <span>{v?.category || "Venue"}</span>
                                {typeof v?.affinity === "number" && <span>{Math.round(v.affinity * 100)}%</span>}
                              </div>
                              {v?.address && (
                                <div style={{ fontSize: 9, color: "var(--text-3)", lineHeight: 1.25, marginTop: 2, paddingRight: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{v.address}</div>
                              )}
                              <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                                {v && (
                                  <a
                                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([v.name, v.address].filter(Boolean).join(", ") || `${v.lat ?? ""},${v.lon ?? ""}`)}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    title={`Open ${v.name} in Google Maps`}
                                    style={{ fontSize: 9, color: "var(--light)", textDecoration: "none" }}
                                    onClick={(e) => e.stopPropagation()}
                                  >gmap ↗</a>
                                )}
                                <a
                                  href={getGCalSingleUrl(starting)}
                                  target="_blank"
                                  rel="noreferrer"
                                  title="Add this stop to Google Calendar"
                                  style={{ fontSize: 9, color: "var(--amber)", textDecoration: "none" }}
                                  onClick={(e) => e.stopPropagation()}
                                >+gcal</a>
                              </div>
                            </div>
                            <div
                              onPointerDown={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                const startY = e.clientY;
                                const startDur = starting.duration || 1;
                                const maxDur = Math.max(1, 23 - starting.startSlot);
                                setResizingUid(starting.uid);
                                document.body.style.userSelect = "none";
                                const onMove = (ev: PointerEvent) => {
                                  const delta = Math.round((ev.clientY - startY) / 32);
                                  const newDur = Math.min(maxDur, Math.max(1, startDur + delta));
                                  setSchedule((prev) => prev.map((x) => (x.uid === starting.uid ? { ...x, duration: newDur } : x)));
                                };
                                const cleanup = () => {
                                  setResizingUid(null);
                                  document.body.style.userSelect = "";
                                  window.removeEventListener("pointermove", onMove);
                                  window.removeEventListener("pointerup", cleanup);
                                  window.removeEventListener("pointercancel", cleanup);
                                };
                                window.addEventListener("pointermove", onMove);
                                window.addEventListener("pointerup", cleanup);
                                window.addEventListener("pointercancel", cleanup);
                              }}
                              style={{ position: "absolute", left: 4, right: 4, bottom: 3, height: 9, cursor: "ns-resize", background: "var(--track-fill)", borderRadius: 4, touchAction: "none", zIndex: 2 }}
                              title="Drag to extend or shrink duration"
                            />
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>


            </table>
          </div>
          {/* Manual Entry Modal */}
          {showAddModal && (
            <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.65)", zIndex: 3000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
              <div className="card" style={{ maxWidth: 440, width: "100%", background: "var(--card)", padding: 20 }}>
                <div className="card-head" style={{ marginBottom: 12 }}>
                  <div>
                    <h2 style={{ fontSize: 16 }}>Add Custom Stop</h2>
                    <p style={{ fontSize: 12 }}>Insert your own curated venue into the schedule</p>
                  </div>
                  <button className="btn" onClick={() => setShowAddModal(false)} style={{ height: 26, fontSize: 12 }}>Close</button>
                </div>
                <div className="stack" style={{ gap: 10 }}>
                  <input
                    className="field"
                    placeholder="Venue / Stop Name (e.g. Host Welcome Lunch)"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                  />
                  <div className="row" style={{ gap: 8 }}>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontSize: 11, color: "var(--text-3)", display: "block", marginBottom: 3 }}>Category</span>
                      <select
                        className="field"
                        value={customCategory}
                        onChange={(e) => setCustomCategory(e.target.value)}
                        style={{ padding: "8px 10px", fontSize: 13 }}
                      >
                        {ALL_TYPES.map((t) => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontSize: 11, color: "var(--text-3)", display: "block", marginBottom: 3 }}>Day</span>
                      <select
                        className="field"
                        value={customDay}
                        onChange={(e) => setCustomDay(Number(e.target.value))}
                        style={{ padding: "8px 10px", fontSize: 13 }}
                      >
                        {Array.from({ length: numDays }, (_, i) => i + 1).map((d) => (
                          <option key={d} value={d}>Day {d}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row" style={{ gap: 8 }}>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontSize: 11, color: "var(--text-3)", display: "block", marginBottom: 3 }}>Time</span>
                      <select
                        className="field"
                        value={customSlot}
                        onChange={(e) => setCustomSlot(Number(e.target.value))}
                        style={{ padding: "8px 10px", fontSize: 13 }}
                      >
                        {Array.from({ length: 22 }, (_, s) => {
                          const hm = slotToHM(s);
                          return (
                            <option key={s} value={s}>
                              {String(hm.h).padStart(2, "0")}:{String(hm.m).padStart(2, "0")}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontSize: 11, color: "var(--text-3)", display: "block", marginBottom: 3 }}>Duration</span>
                      <select
                        className="field"
                        value={customDuration}
                        onChange={(e) => setCustomDuration(Number(e.target.value))}
                        style={{ padding: "8px 10px", fontSize: 13 }}
                      >
                        <option value={1}>30 mins</option>
                        <option value={2}>1 hr</option>
                        <option value={3}>1.5 hrs</option>
                        <option value={4}>2 hrs</option>
                        <option value={6}>3 hrs</option>
                      </select>
                    </div>
                  </div>
                  <input
                    className="field"
                    placeholder="Address or neighborhood (optional)"
                    value={customAddress}
                    onChange={(e) => setCustomAddress(e.target.value)}
                  />
                  <button
                    className="btn btn-primary"
                    onClick={addCustomVenue}
                    disabled={!customName.trim()}
                    style={{ height: 36, marginTop: 6 }}
                  >
                    Add to Schedule
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="row" style={{ marginTop: 10 }}>
            <button className="btn btn-primary" onClick={downloadICS} disabled={schedule.length === 0} title="Downloads standard .ICS calendar file with separate timed events for Google/Apple Calendar">
              Download Calendar (.ICS)
            </button>
            <button className="btn" onClick={downloadCSVCalendar} disabled={schedule.length === 0} title="Google Calendar CSV import format with distinct date & time columns">
              Download Google Calendar CSV
            </button>
            <button className="btn" onClick={exportGoogleCalendar} disabled={schedule.length === 0} title="Open Google Calendar web event creation">
              Open in Google Calendar tabs
            </button>
            <button className="btn" onClick={() => window.print()} disabled={venues.length === 0}>Print PDF summary</button>
            <button className="btn" onClick={saveToBrowser} disabled={venues.length === 0}>Save to browser</button>
            <button className="btn" onClick={clearBrowser}>Clear browser</button>
          </div>
          {saveStatus && <p style={{ color: "var(--text-3)", fontSize: 12, marginTop: 6 }}>{saveStatus}</p>}
          {schedule.length === 0 && <p style={{ color: "var(--text-3)", fontSize: 13, marginTop: 8 }}>Send venues to schedule to start composing.</p>}
        </section>

        {/* Strategic briefing */}
        {rationale && (
          <section id="briefing-section" className="card" style={{ width: "100%" }}>
            <div className="card-head">
              <div>
                <h2>Strategic briefing</h2>
                <p>Corporate strategy report &amp; taste reasoning</p>
              </div>
              <button className="btn" onClick={() => setShowBriefing(true)}>
                Open in modal popup
              </button>
            </div>
            <div className="pick">
              <div className="reason" style={{ whiteSpace: "pre-wrap" }}>{rationale}</div>
            </div>
          </section>
        )}

        {showBriefing && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
            <div className="card" style={{ maxWidth: 760, width: "100%", maxHeight: "85vh", overflow: "auto" }}>
              <div className="card-head">
                <div>
                  <h2>Qloo Graph Resolution &amp; Strategic Briefing</h2>
                  <p>Multidimensional taste signal verification for judges</p>
                </div>
                <button className="btn" onClick={() => setShowBriefing(false)}>Close</button>
              </div>

              {/* Explicit Qloo Mapping Matrix */}
              <div className="pick" style={{ background: "rgba(237,166,69,0.06)", borderColor: "rgba(237,166,69,0.3)" }}>
                <div className="cat" style={{ color: "var(--amber)", fontWeight: 700 }}>
                  ✦ QLOO TASTE GRAPH RESOLUTION MATRIX ({tags.length} signals isolated)
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 8, marginTop: 8 }}>
                  {tags.map((t, idx) => (
                    <div key={idx} style={{ background: "var(--tile)", border: "1px solid var(--line)", borderRadius: 8, padding: "6px 10px", fontSize: 11 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontWeight: 600, color: "#fff" }}>{t.name}</span>
                        <span className="chip" style={{ fontSize: 9, padding: "1px 6px" }}>{t.category}</span>
                      </div>
                      <div style={{ marginTop: 4, color: "var(--text-3)", fontFamily: "monospace", fontSize: 10 }}>
                        {t.qlooTagId ? (
                          <span style={{ color: "#7ee787" }}>
                            ✓ Tag: <strong style={{ color: "#fff" }}>{t.qlooTagName}</strong>
                            <br />
                            <span style={{ opacity: 0.7 }}>{t.qlooTagId}</span>
                          </span>
                        ) : (
                          <span style={{ color: "var(--coral)" }}>Direct Entity Search fallback</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pick">
                <div className="cat">Strategic Rationale &amp; Hometown Bridge</div>
                <div className="reason" style={{ whiteSpace: "pre-wrap" }}>{rationale}</div>
              </div>

              <div className="pick">
                <div className="cat">Qloo Real-time API Transaction Logs</div>
                <div style={{ background: "#0a0908", border: "1px solid var(--line)", borderRadius: 10, padding: 10, fontFamily: "monospace", fontSize: 11, color: "#9cdcfe", maxHeight: 220, overflow: "auto" }}>
                  {logs.map((l, i) => <div key={i}>{l}</div>)}
                </div>
              </div>
            </div>
          </div>
        )}


      {/* Compact execution pane */}
      <div style={{ position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 1000, background: "rgba(10,9,8,0.92)", backdropFilter: "blur(8px)", borderTop: "1px solid var(--line-strong)", padding: "6px 12px", fontFamily: "monospace", fontSize: 11, color: "#9cdcfe", height: 44, overflow: "auto" }}>
        {logs.length === 0 ? "Waiting for execution..." : logs[logs.length - 1]}
      </div>
      </div>
    </div>
  );
}
