export type LLMProvider = "groq" | "openrouter";

export async function callLLM(
  prompt: string,
  provider: LLMProvider = "groq",
  maxTokens = 400,
  opts: { temperature?: number; seed?: number; response_format?: { type: string } } = {}
): Promise<string> {
  if (provider === "openrouter") {
    const key = process.env.OPENROUTER_API_KEY || "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";
    // Verified free lightning fast model on OpenRouter
    const model = process.env.OPENROUTER_MODEL || "nvidia/nemotron-3.5-lightning:free";
    const body: Record<string, unknown> = {
      model,
      messages: [{ role: "user", content: prompt }],
      temperature: opts.temperature ?? 0.3,
      max_tokens: maxTokens,
    };
    if (opts.response_format) body.response_format = opts.response_format;

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
        "HTTP-Referer": "http://localhost:8082",
        "X-Title": "VibeConcierge",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`OpenRouter ${res.status}: ${errText}`);
    }
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return (data.choices?.[0]?.message?.content || "").trim();
  }

  // Verified free high-parameter model on Groq
  const key = process.env.GROQ_API_KEY;
  if (!key) throw new Error("GROQ_API_KEY not set");
  const model = process.env.GROQ_MODEL || "openai/gpt-oss-120b";
  // openai/gpt-oss-120b spends hundreds of tokens on internal reasoning before emitting JSON.
  // We must allow at least 1500 max_tokens to prevent truncation ("json_validate_failed").
  const effectiveMaxTokens = Math.max(maxTokens, 1500);
  const body: Record<string, unknown> = {
    model,
    messages: [{ role: "user", content: prompt }],
    temperature: opts.temperature ?? 0.2,
    max_tokens: effectiveMaxTokens,
  };
  if (typeof opts.seed === "number") body.seed = opts.seed;
  if (opts.response_format) body.response_format = opts.response_format;

  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Groq ${res.status}: ${errText}`);
  }
  const data = (await res.json()) as { choices?: { message?: { content?: string; reasoning?: string } }[] };
  const msg = data.choices?.[0]?.message;
  return (msg?.content?.trim() || msg?.reasoning?.trim() || "").trim();
}
