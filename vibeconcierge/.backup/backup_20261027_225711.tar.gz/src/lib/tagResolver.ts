import { searchTags } from "./qloo";

export type QlooTagCandidate = { id: string; name: string; type: string; popularity: number };

export type TagSelection = { phrase: string; tag: QlooTagCandidate | null };

type UnknownRecord = Record<string, unknown>;

const candidateCache = new Map<string, QlooTagCandidate[]>();

/** Lower is better. Location, media-keyword and artist tags pull generic taste phrases toward the wrong venues. */
export function tagPenalty(id: string): number {
  if (id.includes(":nearby_attraction:") || id.includes(":locality") || id.includes(":geocode")) return 3;
  if (id.startsWith("urn:tag:keyword:media") || id.startsWith("urn:tag:keyword:qloo") || id.startsWith("urn:tag:artist:")) return 2;
  return 0;
}

function asRec(v: unknown): UnknownRecord | null {
  return v && typeof v === "object" ? (v as UnknownRecord) : null;
}

/** Ranked Qloo tag candidates for one free-text phrase (cached per phrase).
 *  Multi-query: also tries key sub-phrases to maximise hit rate.
 */
export async function candidatesFor(phrase: string, limit = 12): Promise<QlooTagCandidate[]> {
  const key = phrase.trim().toLowerCase();
  if (!key) return [];
  const cached = candidateCache.get(key);
  if (cached) return cached.slice(0, limit);

  // Build a set of queries: the full phrase + significant single words (>= 4 chars)
  const words = key.split(/\s+/).filter((w) => w.length >= 4);
  const queries = [phrase, ...words.filter((w) => w !== key)].slice(0, 3);

  const seen = new Set<string>();
  const out: QlooTagCandidate[] = [];

  for (const q of queries) {
    try {
      const res = asRec(await searchTags(q));
      const results = asRec(res?.results);
      const raw: unknown[] = Array.isArray(results?.tags) ? (results.tags as unknown[]) : Array.isArray(res?.results) ? (res.results as unknown[]) : [];
      for (const t of raw) {
        const r = asRec(t) || {};
        const id = typeof r.id === "string" ? r.id : "";
        const name = typeof r.name === "string" ? r.name : "";
        if (!id || !name || seen.has(id)) continue;
        seen.add(id);
        out.push({
          id,
          name,
          type: typeof r.type === "string" ? r.type : "",
          popularity: typeof r.popularity === "number" ? r.popularity : 0,
        });
      }
    } catch {
      // continue with whatever we have
    }
  }

  // Prefer venue-relevant tags; deprioritise media/location noise
  out.sort((a, b) => tagPenalty(a.id) - tagPenalty(b.id) || b.popularity - a.popularity);
  candidateCache.set(key, out);
  return out.slice(0, limit);
}

/**
 * Lets the LLM choose, for each extracted phrase, ONE tag from Qloo's own candidate list.
 * The model never invents tag names: anything it returns that is not in the shortlist is discarded.
 * Falls back to the top-ranked candidate only when that candidate is strongly popular.
 */
export async function selectQlooTags(
  phrases: string[],
  llm: (prompt: string) => Promise<string>,
): Promise<TagSelection[]> {
  // Resolve candidates in parallel for speed
  const candidateLists = await Promise.all(phrases.map((phrase) => candidatesFor(phrase)));
  const shortlist: { phrase: string; candidates: QlooTagCandidate[] }[] = phrases.map((phrase, i) => ({
    phrase,
    candidates: candidateLists[i],
  }));

  const askable = shortlist.filter((s) => s.candidates.length > 0);
  let mappings: { phrase?: string; tag?: string | null }[] = [];
  if (askable.length) {
    try {
      const prompt = `You map user taste phrases onto Qloo's taste-tag vocabulary to maximise coverage.
For each phrase, pick the BEST matching tag from its candidate list. Only return null if truly no candidate is even loosely related.
Rules: copy tag names EXACTLY as written. Never invent tags. Be generous — if a candidate is plausibly related (same scene, genre, aesthetic), choose it.
Return ONLY valid JSON: {"mappings":[{"phrase":string,"tag":string|null}]}
Input: ${JSON.stringify(askable.map((s) => ({ phrase: s.phrase, candidates: s.candidates.map((c) => c.name) })))}`;
      const raw = await llm(prompt);
      const match = raw.match(/\{[\s\S]*\}/);
      const parsed = JSON.parse(match ? match[0] : raw) as { mappings?: { phrase?: string; tag?: string | null }[] };
      mappings = Array.isArray(parsed.mappings) ? parsed.mappings : [];
    } catch {
      mappings = [];
    }
  }

  return shortlist.map((s) => {
    const m = mappings.find((x) => (x.phrase || "").toLowerCase() === s.phrase.toLowerCase());
    const chosenName = (m?.tag || "").toLowerCase();
    const fromLlm = chosenName ? s.candidates.find((c) => c.name.toLowerCase() === chosenName) : undefined;
    if (fromLlm) return { phrase: s.phrase, tag: fromLlm };
    const top = s.candidates[0];
    return { phrase: s.phrase, tag: top && (top.popularity >= 0.1 || tagPenalty(top.id) < 2) ? top : null };
  });
}
